//Heuristic Based Independent Task Scheduling Simulator (HBITS-SIM) by pbanga
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
class HBITSSIM extends Frame implements ActionListener,ItemListener
{
	JPanel p1,p2,p3;
	JButton btnFCFS,btnMET,btnMCT,btnMinMin,btnMaxMin,btnSuff,btnMaxStd,btnRASA,btnNewAlg,btnTASS,btnTASA,btnPickFile,btnInfo,btnExeAll,btnExit,btnETCGen,btnCopyright,btnAbout;
	JComboBox cbDatasets;
	JLabel lblSchName,lblDataset,lblTask,lblVM,lblInfo;
	Font font;
	JTextField tfTask,tfVM,tfFile;
	FileOutputStream fos;
	PrintStream ps;

	HBITSSIM()	//default constructor overridden
	{
		JOptionPane.showMessageDialog(this, "11 Heuristic based Independent Task Scheduling Algorithms are simulated on 6 performance metrices.\n1. Makespan (MK) \n2. Avg. Res util rate (ARUR) \n3. Avg Waiting Time (AWT) \n4. Fitness \n5. Flow time and \n6. Standard Deviation of VM's\nDeveloped by: Dr. Puneet Banga (Inventor), Co-inventors: Dr. Sanjeev Rana & Dr. Sandip Goel \nDepartment of CSE, MM(DU), Mullana (Ambala), Haryana, INDIA");

		p1=new JPanel();
		p2=new JPanel();
		p3=new JPanel();

		btnFCFS=new JButton("1. FCFS");
		btnMET=new JButton("2. MET");
		btnMCT=new JButton("3. MCT");
		btnMinMin=new JButton("4. Min-Min");
		btnMaxMin=new JButton("5. Max-Min");
		btnSuff=new JButton("6. Sufferage");
		btnMaxStd=new JButton("7. MaxStd");
		btnRASA=new JButton("8. RASA");
		btnNewAlg=new JButton("9. New_Alg");
		btnTASS=new JButton("10. TASS");
		btnTASA=new JButton("11. TASA");
		btnExeAll=new JButton("EXE 11 HEURISTICS");
		btnETCGen=new JButton("GENERATE NEW ETC FILE");
		btnExit=new JButton("***EXIT***");
		btnExit.setBackground(Color.RED);
		btnCopyright=new JButton("Copyright \u00A9 2024");
		btnAbout=new JButton("About HBITS-SIM");

		btnPickFile=new JButton("Or Pick Custom ETC File");
		btnInfo=new JButton("GEN_INFO: HBITS-SIM");

		String strDatasets[]={"Pick Braun 12 instances","1. c-hihi","2. c-hilo","3. c-lohi",
		"4. c-lolo","5. i-hihi","6. i-hilo","7. i-lohi","8. i-lolo","9. s-hihi",
		"10. s-hilo","11. s-lohi","12. s-lolo"};

		cbDatasets=new JComboBox(strDatasets);

		lblSchName=new JLabel("Click-->");
		lblDataset=new JLabel("Braun 12 instances (datasets)");
		lblTask=new JLabel("Task(s)= ",JLabel.RIGHT);
		lblVM=new JLabel("Virtual Machine(s)= ",JLabel.RIGHT);

		font = new Font("Verdana", Font.BOLD,15);
		lblInfo=new JLabel("Select dataset: Either from Braun datasets or Existing ETC file from local drive or generate a New ETC", JLabel.CENTER);
		lblInfo.setFont(font);

		tfTask=new JTextField();
		tfVM=new JTextField();
		tfFile=new JTextField(50);

		tfTask.setEditable(false);
		tfVM.setEditable(false);
		tfFile.setEditable(false);

		//adding components into panels
		p1.add(cbDatasets);
		p1.add(btnPickFile);
		p1.add(tfFile);
		p1.add(lblTask);
		p1.add(tfTask);
		p1.add(lblVM);
		p1.add(tfVM);
		//p1.add(lblInputFile);
		//p1.add(btnInfo);
		p2.add(lblInfo);

		//p3.add(lblSchName);
		p3.add(btnFCFS);
		p3.add(btnMET);
		p3.add(btnMCT);
		p3.add(btnMinMin);
		p3.add(btnMaxMin);
		p3.add(btnSuff);
		p3.add(btnMaxStd);
		p3.add(btnRASA);
		p3.add(btnNewAlg);
		p3.add(btnTASS);
		p3.add(btnTASA);
		p3.add(btnExeAll);
		p3.add(btnETCGen);
		p3.add(btnCopyright);
		p3.add(btnAbout);
		p3.add(btnExit);


		//Placement of components using Layout managers
		p1.setLayout(new GridLayout(1,7));
		p2.setLayout(new GridLayout(1,1));
		p3.setLayout(new GridLayout(2,7));


		//placement of frame itself and panels on top
		setLayout(new BorderLayout());		//default layout of Frame or Window

		add(p1,BorderLayout.NORTH);
		add(p2,BorderLayout.CENTER);
		add(p3,BorderLayout.SOUTH);

		//Registration
		btnFCFS.addActionListener(this);
		btnMET.addActionListener(this);
		btnMCT.addActionListener(this);
		btnMinMin.addActionListener(this);
		btnMaxMin.addActionListener(this);
		btnSuff.addActionListener(this);
		btnMaxStd.addActionListener(this);
		btnRASA.addActionListener(this);
		btnNewAlg.addActionListener(this);
		btnTASS.addActionListener(this);
		btnTASA.addActionListener(this);
		btnExeAll.addActionListener(this);

		btnPickFile.addActionListener(this);
		//btnInfo.addActionListener(this);
		btnETCGen.addActionListener(this);
		btnExit.addActionListener(this);
		btnCopyright.addActionListener(this);
		btnAbout.addActionListener(this);

		tfTask.addActionListener(this);
		tfVM.addActionListener(this);
		tfFile.addActionListener(this);
		cbDatasets.addItemListener(this);

		setTitle("Heuristic Based Independent Task Scheduling Simulator (HBITS-SIM) \u00A9");
		setBackground(Color.CYAN);
		setSize(1250,500);
		setResizable(false);				//means can't maximize the frame
		setLocationRelativeTo(null);		//means in middle irrespective of display
		setVisible(true);					//frame is active
	}//constructor end

	void resetButtonColor()
	{
		btnFCFS.setBackground(Color.CYAN);
		btnMET.setBackground(Color.CYAN);
		btnMCT.setBackground(Color.CYAN);
		btnMinMin.setBackground(Color.CYAN);
		btnMaxMin.setBackground(Color.CYAN);
		btnSuff.setBackground(Color.CYAN);
		btnRASA.setBackground(Color.CYAN);
		btnNewAlg.setBackground(Color.CYAN);
		btnMaxStd.setBackground(Color.CYAN);
		btnTASS.setBackground(Color.CYAN);
		btnTASA.setBackground(Color.CYAN);
		btnExeAll.setBackground(Color.CYAN);
		btnExit.setBackground(Color.RED);
	}

	//Method to check whether given string is integer number or not
	boolean checkIntNumber(String num)
	{
		try
		{
			int taskInt = Integer.parseInt(num);
			return true;
		}
		catch (NumberFormatException e)
		{
			return false;
		}
	}

	//-----------------------------------------ActionEvent handling
	public void actionPerformed(ActionEvent ae)
	{
		Object src=ae.getSource();		//capture source


		//click and execute scheduling algorithm
		if(src==btnFCFS)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from datasets readymade or custom input file");
			}
			else
			{
				btnFCFS.setBackground(Color.RED);
				try
				{
					fos=new FileOutputStream("RUN_FILE.txt",false);
					ps=new PrintStream(fos);
				}
				catch(Exception e) { }

				ps.println(tfTask.getText());
				ps.println(tfVM.getText());
				ps.println(tfFile.getText());
				try
				{
					new FCFS();
					lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
					fos.close();
					ps.close();
				}
				catch(Exception e) { }
				}
		}//btn closed

		if(src==btnMET)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from Datasets or custom input file");
			}
			else
			{
			btnMET.setBackground(Color.RED);
			try
			{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);
			}
			catch(Exception e) { }

			ps.println(tfTask.getText());
			ps.println(tfVM.getText());
			ps.println(tfFile.getText());

			System.out.println("task="+tfTask.getText());
			System.out.println("vm="+tfVM.getText());
			System.out.println("File="+tfFile.getText());
			try
			{
				new MET();
				lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
				fos.close();
				ps.close();
			}
			catch(Exception e) { }
		}
		}//btn closed

		if(src==btnMCT)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from Datasets or custom input file");
			}
			else
			{
			btnMCT.setBackground(Color.RED);
			try
			{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);
			}
			catch(Exception e) { }

			ps.println(tfTask.getText());
			ps.println(tfVM.getText());
			ps.println(tfFile.getText());

			System.out.println("task="+tfTask.getText());
			System.out.println("vm="+tfVM.getText());
			System.out.println("File="+tfFile.getText());
			try
			{
				new MCT();
				lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
				fos.close();
				ps.close();
			}
			catch(Exception e) { }
		 }
		}//btn closed

		if(src==btnMinMin)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from Datasets or custom input file");
			}
			else
			{
			btnMinMin.setBackground(Color.RED);
			try
			{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);
			}
			catch(Exception e) { }

			ps.println(tfTask.getText());
			ps.println(tfVM.getText());
			ps.println(tfFile.getText());

			try
			{
				new MinMin();
				lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
				fos.close();
				ps.close();
			}
			catch(Exception e) { }
		}
		}//btn closed

		if(src==btnMaxMin)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from Datasets or custom input file");
			}
			else
			{
			btnMaxMin.setBackground(Color.RED);
			try
			{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);
			}
			catch(Exception e) { }

			ps.println(tfTask.getText());
			ps.println(tfVM.getText());
			ps.println(tfFile.getText());
			try
			{
				new MaxMin();
				lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
				fos.close();
				ps.close();
			}
			catch(Exception e) { }
		}
		}//btn closed

		if(src==btnSuff)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from Datasets or custom input file");
			}
			else
			{
			btnSuff.setBackground(Color.RED);
			try
			{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);
			}
			catch(Exception e) { }

			ps.println(tfTask.getText());
			ps.println(tfVM.getText());
			ps.println(tfFile.getText());

			try
			{
				new Sufferage();
				lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
				fos.close();
				ps.close();
			}
			catch(Exception e) { }
		}
		}//btn closed

		if(src==btnMaxStd)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from Datasets or custom input file");
			}
			else
			{
			btnMaxStd.setBackground(Color.RED);
			try
			{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);
			}
			catch(Exception e) { }

			ps.println(tfTask.getText());
			ps.println(tfVM.getText());
			ps.println(tfFile.getText());

			try
			{
				new MaxStdJava();
				lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
				fos.close();
				ps.close();
			}
			catch(Exception e) { }
		}
		}//btn closed

		if(src==btnRASA)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from Datasets or custom input file");
			}
			else
			{
			btnRASA.setBackground(Color.RED);
			try
			{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);
			}
			catch(Exception e) { }

			ps.println(tfTask.getText());
			ps.println(tfVM.getText());
			ps.println(tfFile.getText());

			try
			{
				new RASA();
				lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
				fos.close();
				ps.close();
			}
			catch(Exception e) { }
		}
		}//btn closed

		if(src==btnNewAlg)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from Datasets or custom input file");
			}
			else
			{
			btnNewAlg.setBackground(Color.RED);
			try
			{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);
			}
			catch(Exception e) { }

			ps.println(tfTask.getText());
			ps.println(tfVM.getText());
			ps.println(tfFile.getText());

			try
			{
				new NewAlg();
				lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
				fos.close();
				ps.close();
			}
			catch(Exception e) { }
		}
		}//btn closed

		if(src==btnTASS)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from Datasets or custom input file");
			}
			else
			{
			btnTASS.setBackground(Color.RED);
			try
			{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);
			}
			catch(Exception e) { }

			ps.println(tfTask.getText());
			ps.println(tfVM.getText());
			ps.println(tfFile.getText());

			try
			{
				new TASS();
				lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
				fos.close();
				ps.close();
			}
			catch(Exception e) { }
		}
		}//btn closed

		if(src==btnTASA)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Select Input: either from Datasets or custom input file");
			}
			else
			{
			btnTASA.setBackground(Color.RED);
			try
			{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);
			}
			catch(Exception e) { }

			ps.println(tfTask.getText());
			ps.println(tfVM.getText());
			ps.println(tfFile.getText());

			try
			{
				new TASA();
				lblInfo.setText("Executed sucessfully, check the Output file: "+tfFile.getText()+"_Output.xls");
				fos.close();
				ps.close();
			}
			catch(Exception e) { }
		}
		}//btn closed


		//All Execution
		if(src==btnExeAll)
		{
			if(tfTask.getText().equals("") || tfVM.getText().equals("") || tfFile.getText().equals(""))
			{
				JOptionPane.showMessageDialog(this, "Either Select Readymade Datasets or pick custom input file!!!");
			}
			else
			{
				try
				{
				fos=new FileOutputStream("RUN_FILE.txt",false);
				ps=new PrintStream(fos);

				ps.println(tfTask.getText());
				ps.println(tfVM.getText());
				ps.println(tfFile.getText());
				btnFCFS.setBackground(Color.RED);
				new FCFS();
				btnMET.setBackground(Color.RED);
				new MET();
				btnMCT.setBackground(Color.RED);
				new MCT();
				btnMinMin.setBackground(Color.RED);
				new MinMin();
				btnMaxMin.setBackground(Color.RED);
				new MaxMin();
				btnSuff.setBackground(Color.RED);
				new Sufferage();
				btnMaxStd.setBackground(Color.RED);
				new MaxStdJava();
				btnRASA.setBackground(Color.RED);
				new RASA();
				btnNewAlg.setBackground(Color.RED);
				new NewAlg();
				btnTASS.setBackground(Color.RED);
				new TASS();
				btnTASA.setBackground(Color.RED);
				new TASA();
				btnExeAll.setBackground(Color.RED);

				lblInfo.setForeground(Color.BLUE);
				lblInfo.setText("11 Heuristics Executed Successfully, check the Output file: "+tfFile.getText()+"_Output.xls");

				fos.close();
				ps.close();

				}catch(Exception e) { }
			}
		}//btnExeAll end

		//btnPickFile code here
		if(src==btnPickFile)
		{
			JOptionPane.showMessageDialog(this, "Pick input ETC file with .txt extension only!");
			JFileChooser jfc = new JFileChooser();
			jfc.showSaveDialog(null);				// Open the save dialog
			File f=jfc.getSelectedFile();
        	String filepath=f.getPath();
        	String withoutExt[]=filepath.split(".txt",2);
        	tfFile.setText(withoutExt[0]);

        	String tasks=JOptionPane.showInputDialog(this,"Number of Tasks"+" for ETC: "+withoutExt[0]);
        	if(!checkIntNumber(tasks))
        	{
				JOptionPane.showMessageDialog(this,"Enter an integer value as per ETC-Tasks");
				tfTask.setText("");
				tfVM.setText("");
				tfFile.setText("");
				lblInfo.setText("Pick the input file again...");
				return;
			}

        	String vms=JOptionPane.showInputDialog(this,"Number of Virtual Machines"+" for ETC: "+withoutExt[0]);
        	if(!checkIntNumber(vms))
		    {
				JOptionPane.showMessageDialog(this,"Enter an integer value as per ETC-Virtual Machines");
				tfTask.setText("");
				tfVM.setText("");
				tfFile.setText("");
				lblInfo.setText("Pick the input file again...");
				return;
			}
        	tfTask.setText(tasks);
			tfVM.setText(vms);
			lblInfo.setText("You have picked: "+f+" as an input ETC.");
			btnPickFile.setBackground(Color.RED);
			cbDatasets.setSelectedIndex(0);
			resetButtonColor();
		}

		if(src==btnETCGen)
		{
			JOptionPane.showMessageDialog(this, "This will create complete ETC matrix. \nGive valid number of tasks and virtual machines.\nNow give input to command prompt behind the simulator screen and then return back.");
			try
			{
				new ETC_Gen_CompleteINT();
			}
			catch(Exception e)
			{
				System.out.println("Under ETC Generation" +e);
			}
		}

		if(src==btnExit)
		{
			dispose();
			System.exit(0);
		}

		if(src==btnCopyright)
		{
			btnCopyright.setBackground(Color.GRAY);
			JOptionPane.showMessageDialog(this, "HBITS-SIM \nAll rights reserved. \nInventor: Dr. Puneet Banga \nYou can reach to me via email: pbanga7@gmail.com or pbanga@mmumullana.org \nThanks");
		}

		if(src==btnAbout)
		{
			btnAbout.setBackground(Color.GRAY);
			if (Desktop.isDesktopSupported())
			{
			    try
			    {
			        File myFile = new File("About HBITS-SIM.pdf");
			        Desktop.getDesktop().open(myFile);
			    }
			    catch (IOException ex)
			    {
			        // no application registered for PDFs
			    }
			}
		}

	}//actionEvent closed

	//ItemEvent handling
	public void itemStateChanged(ItemEvent ie)
	{

		lblInfo.setForeground(Color.BLUE);
		//btnPickFile.setBackground(Color.ORANGE);
		resetButtonColor();

		if(cbDatasets.getSelectedIndex()==1)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("c_hihi");
			lblInfo.setText("You have selected: c_hihi as input file");
		}
		else if(cbDatasets.getSelectedIndex()==2)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("c_hilo");
			lblInfo.setText("You have selected: c_hilo as input file");
		}
		else if(cbDatasets.getSelectedIndex()==3)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("c_lohi");
			lblInfo.setText("You have selected: c_lohi as input file");
		}
		else if(cbDatasets.getSelectedIndex()==4)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("c_lolo");
			lblInfo.setText("You have selected: c_lolo as input file");
		}
		else if(cbDatasets.getSelectedIndex()==5)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("i_hihi");
			lblInfo.setText("You have selected: i_hihi as input file");
		}
		else if(cbDatasets.getSelectedIndex()==6)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("i_hilo");
			lblInfo.setText("You have selected: i_hilo as input file");
		}
		else if(cbDatasets.getSelectedIndex()==7)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("i_lohi");
			lblInfo.setText("You have selected: i_lohi as input file");
		}
		else if(cbDatasets.getSelectedIndex()==8)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("i_lolo");
			lblInfo.setText("You have selected: i_lolo as input file");
		}
		else if(cbDatasets.getSelectedIndex()==9)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("s_hihi");
			lblInfo.setText("You have selected: s_hihi as input file");
		}
		else if(cbDatasets.getSelectedIndex()==10)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("s_hilo");
			lblInfo.setText("You have selected: s_hilo as input file");
		}
		else if(cbDatasets.getSelectedIndex()==11)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("s_lohi");
			lblInfo.setText("You have selected: s_lohi as input file");
		}
		else if(cbDatasets.getSelectedIndex()==12)
		{
			tfTask.setText("512");
			tfVM.setText("16");
			tfFile.setText("s_lolo");
			lblInfo.setText("You have selected: s_lolo as input file");
		}
		else
		{
			//do-nothing here
		}
	}

	//main method here
	public static void main(String args[])
	{
		new HBITSSIM();
	}

}//---------------------------------------------------------------------------------


